/* Shared offline reader: every occurrence resolves to the same concept ID. */
(() => {
  'use strict';
  const data = window.KB_TERMS;
  if (!data || !document.querySelector('main')) return;
  const scriptURL = document.currentScript.src;
  const rootURL = new URL('../', scriptURL);
  const glossaryURL = new URL('review/术语表.html', rootURL);
  const main = document.querySelector('main');
  const normalize = value => value.normalize('NFKC').toLowerCase().replace(/[‐‑‒–—−]/g, '-').replace(/\s+/g, ' ').trim();
  const aliasMap = new Map();
  for (const term of Object.values(data.concepts)) {
    for (const alias of [term.name_zh, term.name_en, ...term.aliases]) {
      const key = normalize(alias);
      const ids = aliasMap.get(key) || [];
      if (!ids.includes(term.id)) ids.push(term.id);
      aliasMap.set(key, ids);
    }
  }
  function lookup(text) {
    const cleaned = normalize(text).replace(/^[“”「」『』'"‘’()（）\s]+|[“”「」『』'"‘’()（）。，,;；:：\s]+$/g, '');
    return (aliasMap.get(cleaned) || []).map(id => data.concepts[id]);
  }
  const escapeRE = value => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const aliases = [...aliasMap.keys()].filter(x => x.length >= 2).sort((a, b) => b.length - a.length);
  const matcher = new RegExp(aliases.map(escapeRE).join('|'), 'gu');
  function mappedText(text) {
    let normalized = '', offset = 0;
    const starts = [], ends = [];
    for (const char of text) {
      let part = char.normalize('NFKC').toLowerCase().replace(/[‐‑‒–—−]/g, '-');
      if (/\s/u.test(char)) part = normalized.endsWith(' ') ? '' : ' ';
      for (let n = 0; n < part.length; n++) { starts.push(offset); ends.push(offset + char.length); }
      normalized += part; offset += char.length;
    }
    return { normalized, starts, ends };
  }
  function matches(text) {
    const { normalized, starts, ends } = mappedText(text), result = [];
    matcher.lastIndex = 0;
    for (const hit of normalized.matchAll(matcher)) {
      const start = hit.index, end = start + hit[0].length;
      if (/^[a-z0-9]/.test(hit[0]) && /[a-z0-9_]/.test(normalized[start - 1] || '')) continue;
      if (/[a-z0-9]$/.test(hit[0]) && /[a-z0-9_]/.test(normalized[end] || '')) continue;
      result.push({ start: starts[start], end: ends[end - 1], ids: aliasMap.get(hit[0]) });
    }
    return result;
  }
  // Existing concept links keep their original destination. Navigation indexes remain direct links.
  for (const a of main.querySelectorAll('a[href]')) {
    const url = new URL(a.href, location.href);
    const cid = decodeURIComponent(url.hash.slice(1));
    if (data.concepts[cid]) {
      a.dataset.concepts = cid;
      a.classList.add('kb-concept-link');
      a.removeAttribute('title');
      if (a.closest('.toc, nav')) a.dataset.directNavigation = 'true';
    }
  }
  const walker = document.createTreeWalker(main, NodeFilter.SHOW_TEXT, {
    acceptNode(node) {
      if (!node.textContent.trim() || node.parentElement.closest('a,button,script,style,pre,code,textarea,input,nav,footer,[data-no-glossary]')) return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    }
  });
  const nodes = []; while (walker.nextNode()) nodes.push(walker.currentNode);
  for (const node of nodes) {
    const hits = matches(node.textContent); if (!hits.length) continue;
    const fragment = document.createDocumentFragment(); let cursor = 0;
    for (const hit of hits) {
      fragment.append(node.textContent.slice(cursor, hit.start));
      const word = document.createElement('span');
      word.className = 'kb-term'; word.dataset.concepts = hit.ids.join(' ');
      word.textContent = node.textContent.slice(hit.start, hit.end);
      word.tabIndex = 0; word.setAttribute('role', 'button'); word.setAttribute('aria-haspopup', 'dialog');
      word.setAttribute('aria-label', word.textContent + '：查看释义');
      fragment.append(word); cursor = hit.end;
    }
    fragment.append(node.textContent.slice(cursor)); node.replaceWith(fragment);
  }

  const toolbar = document.createElement('div'); toolbar.className = 'kb-toolbar';
  const back = document.createElement('button'); back.type = 'button'; back.className = 'kb-back'; back.textContent = '← 返回上一页';
  const tip = document.createElement('span'); tip.textContent = '选中或点按术语，查看释义';
  toolbar.append(back, tip); document.body.prepend(toolbar);
  const panel = document.createElement('aside'); panel.id = 'kb-definition'; panel.className = 'kb-popover'; panel.hidden = true;
  panel.setAttribute('role', 'dialog'); panel.setAttribute('aria-label', '术语释义');
  const panelHead = document.createElement('div'); panelHead.className = 'kb-popover-head';
  const panelBack = document.createElement('button'); panelBack.type = 'button'; panelBack.textContent = '← 上一释义'; panelBack.hidden = true;
  const panelLabel = document.createElement('strong'); panelLabel.textContent = '术语释义';
  const close = document.createElement('button'); close.type = 'button'; close.textContent = '关闭'; close.setAttribute('aria-label', '关闭释义');
  panelHead.append(panelBack, panelLabel, close);
  const content = document.createElement('div'); content.className = 'kb-popover-content';
  panel.append(panelHead, content); document.body.append(panel);
  let current = null, pinned = false, origin = null, hideTimer = 0, hoverTimer = 0, selectionTimer = 0, lastSelection = '', ignoreFocus = false;
  const trail = [];
  const mobile = () => matchMedia('(max-width: 640px)').matches;
  function position(rect) {
    if (mobile()) { panel.style.left = ''; panel.style.top = ''; return; }
    const width = panel.offsetWidth, height = panel.offsetHeight;
    const left = Math.max(12, Math.min(rect.left, innerWidth - width - 12));
    const below = rect.bottom + 10;
    const top = below + height <= innerHeight - 12 ? below : Math.max(64, rect.top - height - 10);
    panel.style.left = left + 'px'; panel.style.top = Math.min(top, Math.max(12, innerHeight - height - 12)) + 'px';
  }
  function appendText(tag, value, className) {
    const el = document.createElement(tag); el.textContent = value;
    if (className) el.className = className; content.append(el); return el;
  }
  function show(ids, rect, mode = 'click', element = null, record = true) {
    ids = ids.filter(id => data.concepts[id]); if (!ids.length) return;
    if (mode === 'hover' && pinned) return;
    clearTimeout(hideTimer);
    const key = ids.join(' ');
    if (record && pinned && current && current.key !== key) trail.push(current);
    if (element) origin = element;
    current = { ids, rect, key }; pinned = mode !== 'hover'; content.replaceChildren();
    for (const id of ids) {
      const term = data.concepts[id];
      const heading = appendText('h2', term.name_zh); heading.id = 'kb-popover-title';
      appendText('p', term.name_en, 'kb-popover-en');
      appendText('p', term.hover, 'kb-popover-brief');
      appendText('p', term.definition);
      const role = appendText('p', '在论文中的作用：' + term.role_in_sun, 'kb-popover-role');
      if (term.prerequisite_ids.length) {
        const group = document.createElement('div'); group.className = 'kb-prerequisites'; group.append('先了解：');
        for (const cid of term.prerequisite_ids) {
          const child = document.createElement('button'); child.type = 'button'; child.textContent = data.concepts[cid].name_zh;
          child.dataset.concepts = cid; group.append(child);
        }
        content.append(group);
      }
      const full = document.createElement('a'); const target = new URL(glossaryURL); target.hash = id;
      full.href = target.href; full.textContent = '查看完整词条 →'; full.className = 'kb-full-entry'; content.append(full);
    }
    panelBack.hidden = trail.length === 0; panel.hidden = false; content.scrollTop = 0;
    panel.dataset.concept = key; panel.dataset.mode = mode; position(rect);
  }
  function dismiss(restoreFocus = false) {
    clearTimeout(hideTimer); clearTimeout(hoverTimer);
    panel.hidden = true; pinned = false; current = null; trail.length = 0;
    if (restoreFocus && origin && origin.isConnected) {
      ignoreFocus = true; origin.focus({ preventScroll: true }); queueMicrotask(() => { ignoreFocus = false; });
    }
  }
  function previousDefinition() {
    if (trail.length) { const previous = trail.pop(); show(previous.ids, previous.rect, 'click', null, false); }
    else dismiss();
  }
  close.addEventListener('click', () => dismiss(true)); panelBack.addEventListener('click', previousDefinition);
  panel.addEventListener('pointerenter', () => clearTimeout(hideTimer));
  panel.addEventListener('pointerleave', () => { if (!pinned) hideTimer = setTimeout(() => dismiss(), 180); });
  document.addEventListener('pointerover', event => {
    if (event.pointerType !== 'mouse' || pinned || event.target.closest('#kb-definition')) return;
    const word = event.target.closest('[data-concepts]'); if (!word) return;
    clearTimeout(hoverTimer);
    hoverTimer = setTimeout(() => show(word.dataset.concepts.split(' '), word.getBoundingClientRect(), 'hover', word), 220);
  });
  document.addEventListener('pointerout', event => {
    const word = event.target.closest('[data-concepts]'); if (!word || pinned) return;
    clearTimeout(hoverTimer);
    if (panel.contains(event.relatedTarget) || word.contains(event.relatedTarget)) return;
    hideTimer = setTimeout(() => dismiss(), 180);
  });
  function selectedTerm() {
    const selection = getSelection();
    if (!selection || selection.isCollapsed || !selection.rangeCount) { lastSelection = ''; return false; }
    const text = selection.toString().trim(); if (!text || text.length > 120) return false;
    const node = selection.anchorNode?.parentElement;
    if (node?.closest('input,textarea,.kb-toolbar')) return false;
    const terms = lookup(text); if (!terms.length) return false;
    const key = normalize(text);
    if (key !== lastSelection || panel.hidden) {
      const rect = selection.getRangeAt(0).getBoundingClientRect();
      show(terms.map(t => t.id), rect, 'selection'); lastSelection = key;
    }
    return true;
  }
  document.addEventListener('selectionchange', () => { clearTimeout(selectionTimer); selectionTimer = setTimeout(selectedTerm, 180); });
  document.addEventListener('pointerup', event => {
    if (event.target.closest('#kb-definition,.kb-toolbar')) return;
    clearTimeout(selectionTimer); selectionTimer = setTimeout(selectedTerm, 25);
  });
  document.addEventListener('pointerdown', event => {
    if (!panel.hidden && !panel.contains(event.target) && !event.target.closest('[data-concepts],.kb-toolbar')) dismiss();
  });
  document.addEventListener('focusin', event => {
    const word = event.target.closest('.kb-term');
    if (word && !pinned && !ignoreFocus) show(word.dataset.concepts.split(' '), word.getBoundingClientRect(), 'hover', word);
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') { dismiss(true); return; }
    if ((event.key === 'Enter' || event.key === ' ') && event.target.matches('.kb-term')) {
      event.preventDefault(); show(event.target.dataset.concepts.split(' '), event.target.getBoundingClientRect(), 'click', event.target);
    }
  });

  // Browser history owns navigation; each entry stores its own scroll and expanded figures.
  const stateKey = '__gradientReader'; let restoring = false, scrollTimer = 0;
  const detailNodes = [...document.querySelectorAll('main details')];
  const pageIdentity = () => location.href;
  function savePosition() {
    if (restoring) return;
    const value = { url: pageIdentity(), x: scrollX, y: scrollY, details: detailNodes.map((d, i) => d.open ? i : -1).filter(i => i >= 0) };
    try { history.replaceState({ ...(history.state || {}), [stateKey]: value }, ''); } catch (_) { /* Native back still works in restricted viewers. */ }
  }
  function restorePosition(saved) {
    if (!saved || saved.url !== location.href) return false;
    restoring = true;
    detailNodes.forEach((node, i) => { node.open = saved.details.includes(i); });
    requestAnimationFrame(() => requestAnimationFrame(() => {
      scrollTo(saved.x, saved.y); restoring = false; updateBack();
    }));
    return true;
  }
  function revealHash(url) {
    const target = document.getElementById(decodeURIComponent(url.hash.slice(1)));
    if (target) { for (let p = target.parentElement; p; p = p.parentElement) if (p.tagName === 'DETAILS') p.open = true; target.scrollIntoView({ block: 'start' }); }
    else if (!url.hash) scrollTo(0, 0);
  }
  function updateBack() {
    const atHome = new URL(location.href).pathname === new URL('index.html', rootURL).pathname;
    back.disabled = history.length <= 1 && atHome;
    back.textContent = history.length <= 1 && !atHome ? '← 返回首页' : '← 返回上一页';
  }
  function goBack() {
    if (!panel.hidden) { previousDefinition(); return; }
    savePosition();
    if (history.length > 1) history.back();
    else location.href = new URL('index.html', rootURL).href;
  }
  back.addEventListener('click', goBack);
  document.addEventListener('click', event => {
    if (event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
    const word = event.target.closest('[data-concepts]');
    if (word && !word.dataset.directNavigation) {
      event.preventDefault(); if (!panel.contains(word) && selectedTerm()) return;
      show(word.dataset.concepts.split(' '), word.getBoundingClientRect(), 'click', word); return;
    }
    const a = event.target.closest('a[href]'); if (!a || a.target === '_blank' || a.hasAttribute('download')) return;
    // A drag selection on a link must not accidentally leave the reading page.
    if (!panel.contains(a) && getSelection()?.toString().trim() && selectedTerm()) { event.preventDefault(); return; }
    const target = new URL(a.href, location.href), here = new URL(location.href);
    const internal = target.href.startsWith(rootURL.href);
    if (!internal) return;
    savePosition(); dismiss();
    if (target.pathname === here.pathname && target.search === here.search) {
      event.preventDefault();
      if (target.href !== here.href) history.pushState({}, '', target.href);
      revealHash(target); savePosition(); updateBack();
    }
  });
  addEventListener('scroll', () => {
    clearTimeout(scrollTimer); scrollTimer = setTimeout(savePosition, 120);
    if (!panel.hidden && !pinned) dismiss();
  }, { passive: true });
  addEventListener('pagehide', savePosition);
  addEventListener('pageshow', () => { dismiss(); if (!restorePosition(history.state?.[stateKey])) savePosition(); updateBack(); });
  addEventListener('popstate', event => { dismiss(); if (!restorePosition(event.state?.[stateKey])) { revealHash(new URL(location.href)); savePosition(); } updateBack(); });
  addEventListener('resize', () => { if (current && !panel.hidden) position(current.rect); });
  if ('scrollRestoration' in history) history.scrollRestoration = 'manual';
  if (!restorePosition(history.state?.[stateKey])) { revealHash(new URL(location.href)); savePosition(); } updateBack();
  window.KBReader = Object.freeze({ lookup, goBack, savePosition, version: '1.2.0' });
})();
