/* Local images remain ordinary links when JavaScript is unavailable. */
(() => {
  'use strict';
  const dialog = document.createElement('dialog');
  if (typeof dialog.showModal !== 'function') return;
  dialog.className = 'kb-image-dialog';
  dialog.setAttribute('aria-labelledby', 'kb-image-title');
  const head = document.createElement('div'); head.className = 'kb-image-dialog-head';
  const close = document.createElement('button'); close.type = 'button'; close.textContent = '← 返回阅读';
  const title = document.createElement('h2'); title.id = 'kb-image-title';
  const zoom = document.createElement('button'); zoom.type = 'button'; zoom.textContent = '查看原尺寸'; zoom.setAttribute('aria-pressed', 'false');
  const help = document.createElement('span'); help.className = 'kb-image-dialog-help'; help.textContent = '原尺寸下可横向滑动';
  const stage = document.createElement('div'); stage.className = 'kb-image-stage'; stage.tabIndex = 0; stage.setAttribute('aria-label', '图片区域，原尺寸时可滚动查看');
  const img = document.createElement('img'); stage.append(img);
  const caption = document.createElement('p'); caption.className = 'kb-image-dialog-caption';
  head.append(close, title, zoom, help); dialog.append(head, stage, caption); document.body.append(dialog);
  let origin = null, width = 1000, recorded = false;
  function setZoom(original) {
    stage.classList.toggle('is-original', original);
    img.style.width = original ? width + 'px' : '';
    zoom.textContent = original ? '适应屏幕' : '查看原尺寸';
    zoom.setAttribute('aria-pressed', String(original));
    stage.scrollTo(0, 0);
  }
  function show(item) {
    img.src = item.src; img.alt = item.title;
    title.textContent = item.title; caption.textContent = item.caption;
    width = item.width || 1000; setZoom(false);
    document.documentElement.classList.add('kb-image-open');
    if (!dialog.open) dialog.showModal();
    close.focus({preventScroll:true});
  }
  function hide() {
    if (dialog.open) dialog.close();
    document.documentElement.classList.remove('kb-image-open');
    if (origin?.isConnected) origin.focus({preventScroll:true});
  }
  function requestClose() {
    if (recorded && history.state?.__kbImage) history.back();
    else hide();
  }
  document.addEventListener('click', event => {
    const link = event.target.closest('a[data-image-viewer]');
    if (!link || event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
    event.preventDefault(); event.stopImmediatePropagation();
    window.KBReader?.savePosition(); origin = link;
    const item = {src:link.href, title:link.dataset.title || link.querySelector('img')?.alt || '图片',
      caption:link.dataset.caption || '', width:Number(link.dataset.width) || 1000};
    try {
      history.pushState({...history.state, __kbImage:item}, '', location.href);
      recorded = true;
    } catch (_) { recorded = false; }
    show(item);
  }, true);
  close.addEventListener('click', requestClose);
  dialog.addEventListener('cancel', event => {event.preventDefault(); requestClose();});
  zoom.addEventListener('click', () => setZoom(!stage.classList.contains('is-original')));
  dialog.addEventListener('click', event => {if (event.target === dialog) requestClose();});
  addEventListener('popstate', event => {if (event.state?.__kbImage) show(event.state.__kbImage); else hide();});
  addEventListener('pageshow', () => {if (history.state?.__kbImage) {recorded=true;show(history.state.__kbImage);}});
})();
