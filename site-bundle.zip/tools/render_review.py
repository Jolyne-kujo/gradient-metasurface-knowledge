"""Small static review companion. No application framework or external assets."""
from pathlib import Path
import json,html,re,struct
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'review'; OUT.mkdir(exist_ok=True)
k=json.loads((ROOT/'data/knowledge_base.json').read_text(encoding='utf-8'))
visuals=json.loads((ROOT/'data/visuals.json').read_text(encoding='utf-8'))['visuals']
visual_index={v['id']:v for v in visuals}
index={v['id']:v for values in k.values() if isinstance(values,list) for v in values if isinstance(v,dict) and 'id' in v}
esc=lambda x:html.escape(str(x),quote=True)
# All six pages share this generated dictionary, including Chinese/English aliases.
term_fields=['id','name_zh','name_en','aliases','hover','definition','role_in_sun','prerequisite_ids']
term_data={c['id']:{field:c[field] for field in term_fields} for c in k['concepts']}
(OUT/'terms-data.js').write_text('/* Generated from data/knowledge_base.json; edit its source concepts. */\nwindow.KB_TERMS = Object.freeze('+json.dumps({'version':'1.1.0','concepts':term_data},ensure_ascii=False,separators=(',',':'))+');\n',encoding='utf-8')
def reader_assets(prefix=''):
    return f'<link rel="stylesheet" href="{prefix}reader.css"><link rel="stylesheet" href="{prefix}visuals.css"><script defer src="{prefix}terms-data.js"></script><script defer src="{prefix}reader.js"></script><script defer src="{prefix}images.js"></script>'
labels_zh={'foundation':'基础','core':'核心','advanced':'进阶','peripheral':'背景',
 'teaching':'教学补充','course_definition':'课程计算定义','derived_from_sun':'根据原文推导',
 'sun_eq_1_2':'原文式(1)(2)','sun_fig4':'原文图4','sun_si_eq_s1':'原文式(S1)','sun_unnumbered':'原文未编号关系式',
 'theory_source':'理论来源','later_improvement':'后续改进','thesis':'博士论文','research_paper':'研究论文',
 'author_mechanism':'作者机制解释','derived':'参数推导','author_simulation_and_experiment':'作者仿真与实验',
 'author_report':'作者报告','author_definition':'作者定义','author_simulation':'作者仿真','author_method':'作者方法',
 'bibliographic_and_course':'文献与课程要求','author_theory':'作者理论','later_theory':'后续理论',
 'course_historical_run':'课程历史运行','course_comparison':'课程结果比较',
 'author_geometry':'作者几何参数','author_material':'作者材料','author_unreported':'原文未列出',
 'author_condition':'作者条件','author_experiment':'作者实验','course_replacement':'课程替代模型',
 'course_assumption':'课程假设','course_setting':'课程设置',
 'local_pdf':'本地PDF','local_text':'本地文本','web':'在线来源',
 'author_institution_abstract_and_metadata':'作者机构摘要及书目信息','author_institution_pdf':'作者机构PDF（相关章节）',
 'publisher_abstract_and_metadata':'出版社摘要及书目信息','author_preprint_full_text':'作者预印本正文（相关章节）','official_documentation':'官方文档'}
zh=lambda value:labels_zh.get(value,value)
css='''*{box-sizing:border-box}html{scroll-behavior:auto}body{margin:0;background:#f5f4ef;color:#222d36;font:17px/1.85 "Microsoft YaHei","Noto Sans CJK SC",sans-serif}main{max-width:1080px;margin:auto;padding:40px 34px 90px}h1{font-size:34px;line-height:1.4;margin:14px 0 18px}h2{font-size:25px;line-height:1.5;margin:36px 0 15px}h3{font-size:21px;line-height:1.55;margin:0 0 12px}h4{margin:18px 0 5px}p{margin:8px 0 14px}a{color:#126078;text-underline-offset:3px}a:hover{color:#8c3f17}nav{display:flex;gap:10px 22px;flex-wrap:wrap;border-bottom:1px solid #b9c6cc;padding-bottom:16px;font-size:15px}.eyebrow{font-size:14px;letter-spacing:2px;color:#516770}.lead{font-size:20px;line-height:1.75}.card{background:#fff;border:1px solid #d8dedf;border-radius:8px;padding:24px 28px;margin:20px 0;scroll-margin-top:20px}.tag{font-size:13px;background:#e8f1ef;color:#25584a;padding:3px 8px;border-radius:3px;margin-right:10px}.meta{font-size:14px;color:#5b6770;overflow-wrap:anywhere}.hint{border-left:4px solid #337e87;background:#eef5f3;padding:12px 18px}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px}.grid .card{margin:0}.toc{columns:3;column-gap:25px;font-size:15px}.toc a{display:block;margin:0 0 6px;break-inside:avoid}table{width:100%;border-collapse:collapse;background:white;font-size:15px;margin:15px 0 28px}th,td{padding:12px;border:1px solid #d4dddf;text-align:left;vertical-align:top;overflow-wrap:anywhere}th{background:#eaf0ef}code,pre{font-family:Consolas,"Microsoft YaHei",monospace}pre{white-space:pre-wrap;overflow-wrap:anywhere;font-size:14px;background:#eff2f2;padding:14px}details{margin:12px 0}summary{cursor:pointer;color:#126078}.page-preview{display:block;width:min(100%,770px);height:auto;margin:18px auto;border:1px solid #d2dadd}.term{border-bottom:1px dotted #90a7ac;text-decoration:none}.refs{font-size:14px;color:#57676c}.equation{font:20px/1.8 "Cambria Math","Microsoft YaHei",serif;padding:14px 0;overflow-wrap:anywhere}li{margin:5px 0}ol,ul{padding-left:25px}footer{margin-top:40px;border-top:1px solid #becace;padding-top:20px;font-size:14px;color:#55656c}@media(max-width:750px){main{padding:22px 18px}h1{font-size:28px}.grid{grid-template-columns:1fr}.toc{columns:2}.card{padding:20px}table{font-size:13px}th,td{padding:8px}}@media print{body{background:white;font-size:11pt}main{max-width:none;padding:0}nav{display:none}.card{break-inside:avoid;box-shadow:none}.toc{columns:3}a{color:inherit}details{display:block}.page-preview{max-height:22cm;width:auto;max-width:100%}}'''
(OUT/'style.css').write_text(css,encoding='utf-8')
routes={'c.':'术语表.html','eq.':'公式与符号.html','sym.':'公式与符号.html','fig.':'逐图与参数.html','param.':'逐图与参数.html','claim.':'逐图与参数.html','route.':'阅读路线.html','paper.':'阅读路线.html','candidate.':'阅读路线.html','a.':'来源证据.html','src.':'来源证据.html'}
def label(item):return item.get('name_zh') or item.get('title') or item.get('name') or item.get('display') or item.get('locator') or item.get('text') or item['id']
def link(rid):
    item=index.get(rid)
    if not item:return '<strong>缺失：'+esc(rid)+'</strong>'
    file=next((v for prefix,v in routes.items() if rid.startswith(prefix)),'来源证据.html')
    tip=item.get('hover',label(item))
    return f'<a href="{file}#{esc(rid)}" title="{esc(tip)}">{esc(label(item))}</a>'
def links(ids):return ' · '.join(link(rid) for rid in ids) if ids else '从本条开始即可'
def refs(ids):return '<p class="refs">来源位置：'+links(ids)+'</p>'
def picture(vid,home=False):
    v=visual_index[vid];prefix='' if home else '../'
    src=prefix+v['path']
    kinds={'paper_crop':'论文原图','teaching_diagram':'教学示意','historical_simulation_plot':'实算数据整理图','native_solver_export':'FDTD 原生导出'}
    source=''
    if v.get('source_path'):source=f' · <a href="{prefix}{esc(v["source_path"])}#page={v["pdf_page"]}">核对原 PDF 第 {v["pdf_page"]} 页</a>'
    return f'<figure class="kb-visual"><a class="kb-image-link" href="{esc(src)}" data-image-viewer data-width="{v["width"]}" data-title="{esc(v["title"])}" data-caption="{esc(v["caption"])}" aria-label="放大：{esc(v["title"])}"><img loading="lazy" decoding="async" width="{v["width"]}" height="{v["height"]}" src="{esc(src)}" alt="{esc(v["title"])}：{esc(v["caption"])}"><span class="kb-image-hint">点击放大 · 可查看原尺寸</span></a><figcaption><span class="tag">{kinds[v["kind"]]}</span><strong>{esc(v["title"])}</strong><p>{esc(v["caption"])}</p>{source}</figcaption></figure>'
def concept_pictures(cid):
    return ''.join(picture(v['id']) for v in visuals if v['kind']=='teaching_diagram' and cid in v['concept_ids'])
def ul(items):return '<ul>'+''.join('<li>'+esc(x)+'</li>' for x in items)+'</ul>'
def paragraph(label_,text):return '<p><strong>'+esc(label_)+'：</strong>'+esc(text)+'</p>'
def inline(text,ids):
    labels={}
    for cid in ids:
        c=index[cid]
        for term in [c['name_zh']]+c['aliases']:
            if len(term)>=2 and re.search('[\u4e00-\u9fff]',term):labels.setdefault(term,cid)
    if not labels:return esc(text)
    parts=[];last=0
    for m in re.finditer('|'.join(map(re.escape,sorted(labels,key=len,reverse=True))),text):
        parts.append(esc(text[last:m.start()]));c=index[labels[m.group()]]
        parts.append(f'<a class="term" href="术语表.html#{c["id"]}" title="{esc(c["hover"])}">{esc(m.group())}</a>');last=m.end()
    parts.append(esc(text[last:]));return ''.join(parts)
def page(file,title,body):
    nav='<nav><a href="../index.html">首页</a><a href="图解与仿真.html">图解与仿真</a><a href="术语表.html">术语</a><a href="阅读路线.html">路线与文献</a><a href="逐图与参数.html">逐图与参数</a><a href="公式与符号.html">公式</a><a href="来源证据.html">来源</a></nav>'
    s=f'<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(title)}</title><link rel="stylesheet" href="style.css"></head><body><main>{nav}<h1>{esc(title)}</h1>{body}<footer>梯度超表面知识库 · 2026-10-31 · 数据版本1.0.0<br>原文、补充材料及课程证据随库保存；术语解释与教学类比为本库整理。</footer></main></body></html>'
    s=s.replace('</head>',reader_assets()+'</head>').replace('2026-10-31 · 数据版本1.0.0','图文更新 2026-11-03 · 阅读器版本1.2.0')
    (OUT/file).write_text(s,encoding='utf-8')
level_names={'foundation':'基础：先读懂波与矢量','core':'核心：解释Sun论文','advanced':'进阶：提高仿真与效率分析能力','peripheral':'背景：按需查阅'}
body='<p class="lead">先看一句话解释，再按“直观理解 → 准确定义 → 本文作用”展开。选中或点按术语即可查看释义；目录链接可直接跳转。</p>'
for level,name in level_names.items():
    selected=[c for c in k['concepts'] if c['level']==level]
    body+='<h2>'+name+'</h2><div class="toc">'+''.join(link(c['id']) for c in selected)+'</div>'
    for c in selected:
        related=c['explanation_concept_ids'];body+=f'<article class="card" id="{c["id"]}"><span class="tag">{esc(zh(c["level"]))}</span><h3>{esc(c["name_zh"])}</h3><p class="meta">{esc(c["name_en"])}</p><p class="hint">{esc(c["hover"])}</p><h4>直观理解</h4><ol>'
        body+=''.join('<li>'+inline(t,related)+'</li>' for t in c['intuitive_steps'])+'</ol>'
        for title,key in [('准确定义','definition'),('在Sun论文中的作用','role_in_sun')]:body+='<p><strong>'+title+'：</strong>'+inline(c[key],related)+'</p>'
        body+=concept_pictures(c['id'])
        body+='<p><strong>先读：</strong>'+links(c['prerequisite_ids'])+'</p>'
        if c['equation_ids']:body+='<p><strong>相关公式：</strong>'+links(c['equation_ids'])+'</p>'
        if c['theory_paper_ids']:body+='<p><strong>理论来源：</strong>'+links(c['theory_paper_ids'])+'</p>'
        if c['later_paper_ids']:body+='<p><strong>后续研究：</strong>'+links(c['later_paper_ids'])+'</p>'
        body+=paragraph('单位',c['units'])+paragraph('同义词','、'.join(c['aliases']))+refs(c['source_anchor_ids'])+'</article>'
page('术语表.html','100个概念：从基础到论文',body)
body='<p class="lead">原文公式、由原文参数计算的关系式和教学补充公式分别标注。先看文字形式，再核对符号和条件。</p><div class="toc">'+''.join(link(e['id']) for e in k['equations'])+'</div>'
for e in k['equations']:
    body+=f'<article class="card" id="{e["id"]}"><span class="tag">{esc(zh(e["origin"]))}</span><h3>{esc(e["title"])}</h3><div class="equation">{esc(e["plain_text"])}</div>'+paragraph('适用条件',e['conditions'])+'<p>符号：'+links(e['symbol_ids'])+'</p><p>相关概念：'+links(e['concept_ids'])+'</p><details><summary>LaTeX表达式</summary><pre>'+esc(e['latex'])+'</pre></details>'+refs(e['source_anchor_ids'])+'</article>'
body+='<h2>符号表：同一字母按语境区分</h2><table><tr><th>符号</th><th>含义</th><th>单位</th><th>辨析与概念</th></tr>'
for s in k['symbols']:body+=f'<tr id="{s["id"]}"><td>{esc(s["display"])}</td><td>{esc(s["meaning_zh"])}</td><td>{esc(s["unit"])}</td><td>{esc(s["disambiguation"])}<br>{links(s["concept_ids"])}</td></tr>'
page('公式与符号.html','26组公式与89个符号',body+'</table>')
body='<p class="lead">围绕“做了什么、证据是什么、怎样复现”阅读论文。12张原图直接配在解读旁，点击放大后可切换原尺寸；每张图均链接到原PDF页。</p><p><a href="#paper-figures">跳到论文原图 ↓</a> · <a href="图解与仿真.html#simulation">查看课程实算场图与效率曲线 →</a></p><h2>重要结论</h2>'
for q in k['claims']:
    body+=f'<article class="card" id="{q["id"]}"><span class="tag">{esc(zh(q["evidence_type"]))}</span><h3>{esc(q["text"])}</h3>'+paragraph('条件',q['conditions'])+'<p>'+esc(q['interpretation'])+'</p>'+refs(q['source_anchor_ids'])+'</article>'
body+='<h2 id="paper-figures">主文与补充材料的12张图</h2><div class="toc">'+''.join(link(f['id']) for f in k['figures'])+'</div>'
for f in k['figures']:
    body+=f'<article class="card" id="{f["id"]}"><h3>{esc(f["title"])}</h3><p class="hint">{esc(f["reading_question"])}</p>'+picture('v.'+f['id'])+ul(f['panel_guide'])
    for label_,key in [('坐标及归一化','axes_and_normalization'),('读图要点','interpretation_limit'),('课程用途','course_use')]:body+=paragraph(label_,f[key])
    image_width,image_height=struct.unpack('>II',(ROOT/f['preview_path']).read_bytes()[16:24])
    body+='<p>相关概念：'+links(f['concept_ids'])+'</p>'+refs(f['source_anchor_ids'])+f'<details><summary>展开原论文整页截图（含图注）</summary><a data-image-viewer data-width="{image_width}" data-title="{esc(f["title"])}所在原文整页" data-caption="原PDF整页截图，含原始图注；可通过上方链接打开PDF核对。" href="../{esc(f["preview_path"])}"><img loading="lazy" width="{image_width}" height="{image_height}" class="page-preview" src="../{esc(f["preview_path"])}" alt="{esc(f["title"])}所在原文页"></a></details></article>'
body+='<h2>模型参数：作者与课程实现分列</h2><p>“未列出”对应JSON中的null；不能以课程默认设置填补作者方法。</p><table><tr><th>参数</th><th>数值与单位</th><th>来源类别</th><th>使用说明与证据</th></tr>'
for p in k['parameters']:
    value='未列出' if p['value'] is None else (json.dumps(p['value'],ensure_ascii=False) if isinstance(p['value'],(list,dict)) else str(p['value']))
    body+=f'<tr id="{p["id"]}"><td>{esc(p["name"])}</td><td>{esc(value)}<br>{esc(p["unit"])}</td><td>{esc(zh(p["origin"]))}</td><td>{esc(p["note"])}<br>{links(p["source_anchor_ids"])}</td></tr>'
page('逐图与参数.html','论文观点、图解与模型参数',body+'</table>')
body='<p class="lead">前置概念回答“先懂什么”，理论来源回答“结论从哪里来”，后续研究回答“还能怎样改进”。三者分开阅读。</p>'
for route in k['reading_routes']:
    body+=f'<article class="card" id="{route["id"]}"><h2>{esc(route["title"])}</h2>'+paragraph('适合',route['audience'])+'<ol>'
    for step in route['steps']:
        body+='<li><strong>'+esc(step['title'])+'</strong><p>'+esc(step['task'])+'</p>'
        for key in ['concept_ids','paper_ids','figure_ids','candidate_ids']:
            if step.get(key):body+='<p>'+links(step[key])+'</p>'
        body+='</li>'
    body+='</ol></article>'
body+='<h2>核心论文与理论文献</h2>'
for p in k['papers']:
    body+=f'<article class="card" id="{p["id"]}"><span class="tag">{esc(zh(p["relation_to_sun"]))}</span><h3>{esc(p["title"])}</h3><p class="meta">{esc(", ".join(p["authors"]))}<br>{esc(p["venue"])} · {esc(p["date"])} ({esc(p["date_type"])})<br>DOI: {esc(p["doi"])}</p>'
    body+='<p>'+esc(p['why_read'])+'</p>'+ul(p['reading_targets'])+paragraph('阅读状态',p['read_status'])+f'<p><a href="{esc(p["url"])}">原文或作者页面</a>'
    for key,label_ in [('supplement_url','补充材料'),('preprint_url','作者预印本')]:
        if p.get(key):body+=f' · <a href="{esc(p[key])}">{label_}</a>'
    body+='</p>'+refs(p['source_anchor_ids'])+'</article>'
body+='<h2>博士论文与近期研究候选</h2><p>以下6项为文献检索候选记录。本库尚未独立逐页核读其全文，先用于安排阅读，不作为已核验参数库。日期按实际年份列出。</p>'
for p in k['candidate_readings']:
    body+=f'<article class="card" id="{p["id"]}"><span class="tag">{esc(zh(p["kind"]))}</span><h3>{esc(p["title"])}</h3><p class="meta">{esc(", ".join(p["authors"]))}<br>{esc(p["venue"])} · {esc(p["date"])}<br>{esc("DOI: "+p["doi"] if p["doi"] else "ISBN: "+p.get("isbn",""))}</p><p>{esc(p["why_read"])}</p>'+paragraph('阅读层次',p['reading_level'])+paragraph('范围与阅读状态',p['scope_limit'])+f'<p><a href="{esc(p["url"])}">机构或出版社页面</a>'
    for key,label_ in [('pdf_url','PDF'),('preprint_url','同一工作的预印本')]:
        if p.get(key):body+=f' · <a href="{esc(p[key])}">{label_}</a>'
    body+='</p>'
    if p.get('preprint_date'):body+=paragraph('预印本日期',p['preprint_date'])
    body+='</article>'
page('阅读路线.html','从入门到仿真的4条阅读路线',body)
body='<p class="lead">本地证据按文件、PDF页码和文字片段定位。在线文献保留访问层次，摘要阅读与正文阅读分别标注。</p><h2>源文件与在线来源</h2>'
for s in k['sources']:
    target='../'+s['path'] if s.get('path') else s['url']
    body+=f'<article class="card" id="{s["id"]}"><h3>{esc(s["title"])}</h3><p><a href="{esc(target)}">打开来源</a></p><p class="meta">{esc(zh(s["kind"]))} · 核对日期 {esc(s["verified_on"])}</p>'
    if s.get('sha256'):body+='<details><summary>文件SHA-256</summary><pre>'+s['sha256']+'</pre></details>'
    if s.get('access_level'):body+=paragraph('访问层次',zh(s['access_level']))
    if s.get('note'):body+='<p>'+esc(s['note'])+'</p>'
    body+='</article>'
body+='<h2>57个原文定位锚点</h2>'
for a in k['anchors']:
    source=index[a['source_id']];target=('../'+source['path'] if source.get('path') else source['url'])+(('#page='+str(a['pdf_page'])) if a['pdf_page'] else '')
    body+=f'<article class="card" id="{a["id"]}"><h3>{esc(a["locator"])}</h3><p class="meta">{a["id"]} · {esc(source["title"])}'
    if a['pdf_page']:body+=f' · PDF第{a["pdf_page"]}页 · 原页码{esc(a["printed_page"])}'
    body+='</p><p>'+esc(a['evidence_role'])+'</p><p class="hint">定位文字：'+esc(a['quote'])+'</p>'+f'<p><a href="{esc(target)}">跳转到来源</a></p></article>'
page('来源证据.html','来源与原文位置',body)
body='<p class="lead">先用示意图读懂机制，再与论文原图和课程实算结果对照。所有图片可离线查看、点击放大。</p><p class="hint">论文原图保留作者证据；教学示意解释概念；课程结果取自2026年10月30日实际运行。三类图片分别标注。</p><div class="toc">'
for v in visuals:
    if v['kind']=='teaching_diagram':body+=f'<a href="#{v["id"]}">{esc(v["title"])}</a>'
body+='<a href="#simulation">课程实算：三分量场与效率谱</a><a href="逐图与参数.html#paper-figures">论文主文图1–5与补充图S1–S7</a></div>'
for v in visuals:
    if v['kind']=='teaching_diagram':
        body+=f'<article class="card" id="{v["id"]}"><h2>{esc(v["title"])}</h2>'+picture(v['id'])+'<p>相关概念：'+links(v['concept_ids'])+'</p>'
        if v['source_anchor_ids']:body+=refs(v['source_anchor_ids'])
        else:body+='<p class="refs">设置来源：<a href="../sources/course_build.lsf">课程建模脚本</a>、<a href="../sources/course_fields.lsf">场监视器与后处理</a>。</p>'
        body+='</article>'
body+='<h2 id="simulation">课程实算：三分量电场与反射效率</h2><p>以下结果由 Lumerical 2020 R2.4 在2026年10月30日运行获得，采用 Au Johnson–Christy 材料模型、5 nm 金属网格。原生导出图保留软件图例，统一排版图用于比较三分量的相对强弱。</p>'
body+='<article class="card" id="simulation-fields"><h3>Ex 主要呈镜面波前，Ey 呈倾斜波前</h3>'+picture('v.sim-fields')+'<p>该场图模型为<strong>正入射、45°线偏振</strong>，不是45°入射。颜色表示电场实部的正负和大小，不能直接当作强度；强度相关量应由复场或坡印廷通量计算。Ey 相位拟合角约45.67°，周期关系给出45.10°。</p><p>对照论文：'+links(['fig.main4'])+'</p><details><summary>查看三张 FDTD 原生场图</summary>'
for vid in ['v.sim-ex','v.sim-ey','v.sim-ez']:body+=picture(vid)
body+='</details></article><article class="card" id="simulation-efficiency"><h3>目标反射方向集中，绝对效率仍受损耗限制</h3>'+picture('v.sim-efficiency')+'<p>此模型使用<strong>纯 y 偏振</strong>。850 nm 时，目标 +1 级绝对效率为75.0385%，总反射率为75.8138%；目标级次占反射功率98.9774%。两者分母不同。</p><p>当前5 nm基线与历史4 nm结果存在约9.14个百分点差异；下一步先统一设置、完成网格收敛，再评价优化效果。</p><p><a href="assets/simulation/本次结果数值.json">850 nm 数值</a> · <a href="assets/simulation/反射效率数据.csv">完整效率谱 CSV</a> · <a href="assets/simulation/运行说明.txt">模型与运行记录</a></p><p>对照论文：'+links(['fig.main5','fig.s7'])+'</p></article>'
page('图解与仿真.html','看图读懂：机制、结构与仿真',body)
landing=f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>梯度超表面知识库</title><link rel="stylesheet" href="review/style.css"></head><body><main><p class="eyebrow">工程光学 · 文献解读与仿真实践</p><h1>梯度超表面的高效宽带异常反射</h1><p class="lead">围绕Sun等2012年论文，从波与相位开始，读懂结构、机制、效率和FDTD验证。</p><p class="hint">相位梯度决定目标方向；真正的高效率还取决于反射振幅、单元耦合、寄生级次和材料损耗。</p><div class="grid"><article class="card"><h2>先读懂概念</h2><p>100个术语，包含一句话解释、直观理解、定义、本文作用与前置知识。</p><a href="review/术语表.html">打开术语表 →</a></article><article class="card"><h2>按路线阅读</h2><p>4条阅读路线；核心与理论文献5篇，博士论文及近期研究候选6项。</p><a href="review/阅读路线.html">打开路线与文献 →</a></article><article class="card"><h2>按图核对证据</h2><p>12张图的阅读提示、13条结论和28项模型参数，配原文页面。</p><a href="review/逐图与参数.html">打开逐图解读 →</a></article><article class="card"><h2>公式与符号</h2><p>26组公式、89个符号，逐项标明单位、适用条件及来源。</p><a href="review/公式与符号.html">打开公式表 →</a></article></div><h2>课程实践主线</h2><p>单元幅相扫描 → 十棒完整超胞 → Ex/Ey/Ez场图 → 目标级次与总功率 → 网格收敛 → 顶部金棒厚度优化。</p><p>2026-10-30的5 nm网格结果已作为历史证据收录；4 nm与5 nm结果仍需统一设置后作收敛研究。</p><h2>数据与来源</h2><p><a href="data/knowledge_base.json">完整JSON</a> · <a href="data/schema.json">JSON Schema</a> · <a href="数据结构说明.txt">数据结构说明</a> · <a href="evidence/validation_report.json">校验报告</a> · <a href="review/来源证据.html">原文锚点</a></p><p class="meta">所有阅读页均可离线打开。未来论文阅读器可读取JSON及正文词条位置；本版提供知识内容与静态查阅入口。</p><footer>版本1.0.0 · 2026-10-31 · 简体中文<br>主文、SI及课程要求均已核读；博士论文和近期研究候选的全文阅读状态另列。</footer></main></body></html>'''
landing=landing.replace('</head>',reader_assets('review/')+'</head>')
landing=landing.replace('本版提供知识内容与静态查阅入口。','支持选词释义、点按术语，以及返回上一页并恢复阅读位置。')
landing=landing.replace('<div class="grid">','<div class="visual-start"><a href="review/图解与仿真.html">先看图解：7张概念示意 + 5张实算结果图 →</a><a href="review/逐图与参数.html#paper-figures">查看12张论文原图 →</a></div>'+picture('v.fig.main1',home=True)+'<div class="grid">',1)
landing=landing.replace('配原文页面。','配可放大的原图与整页截图。').replace('版本1.0.0 · 2026-10-31','图文版1.2.0 · 2026-11-03')
(ROOT/'index.html').write_text(landing,encoding='utf-8')
print('Rendered index.html and six review pages with paper figures, diagrams and simulation images.')
