"""Validate schema, knowledge links, source evidence, text coordinates and physics checks."""
from pathlib import Path
from collections import Counter,defaultdict
from hashlib import sha256
from html.parser import HTMLParser
from urllib.parse import urlsplit,unquote
import json,math,re,unicodedata
import jsonschema
ROOT=Path(__file__).resolve().parents[1]
read=lambda p:json.loads((ROOT/p).read_text(encoding='utf-8'))
k=read('data/knowledge_base.json'); schema=read('data/schema.json'); pages=read('evidence/source_pages.json')
errors=[]; warnings=[]; checks=[]
def check(condition,message):
    checks.append({'check':message,'passed':bool(condition)})
    if not condition:errors.append(message)
for error in jsonschema.Draft202012Validator(schema).iter_errors(k): errors.append('schema '+str(list(error.path))+': '+error.message)
check(not errors,'JSON Schema 2020-12 contract')
entities=[v for values in k.values() if isinstance(values,list) for v in values if isinstance(v,dict) and 'id' in v]
ids=[v['id'] for v in entities]; counts=Counter(ids)
check(all(v==1 for v in counts.values()),'all entity IDs unique')
index={v['id']:v for v in entities}; pindex={p['id']:p for p in pages}
check(len(pindex)==len(pages),'all source page IDs unique')
ref_prefix={'prerequisite_ids':'c.','explanation_concept_ids':'c.','concept_ids':'c.','source_anchor_ids':'a.','equation_ids':'eq.','symbol_ids':'sym.','theory_paper_ids':'paper.','later_paper_ids':'paper.','paper_ids':'paper.','figure_ids':'fig.','candidate_ids':'candidate.'}
def visit(obj,path=''):
    if isinstance(obj,dict):
        for key,value in obj.items():
            if key in ref_prefix:
                for rid in value:
                    if rid not in index or not rid.startswith(ref_prefix[key]):errors.append('broken reference '+path+'/'+key+': '+rid)
            elif key in ('source_id','from_id','to_id') and value not in index:errors.append('broken reference '+str(value))
            elif key=='page_id' and value is not None and value not in pindex:errors.append('broken page '+value)
            visit(value,path+'/'+key)
    elif isinstance(obj,list):
        for i,v in enumerate(obj):visit(v,path+'/'+str(i))
visit(k)
check(not any('broken' in e for e in errors),'all typed references resolve')
graph={c['id']:c['prerequisite_ids'] for c in k['concepts']}; active=set(); done=set(); cycles=[]
def dfs(node,trail):
    if node in active:cycles.append(trail+[node]);return
    if node in done or node not in graph:return
    active.add(node)
    for nxt in graph[node]:dfs(nxt,trail+[node])
    active.remove(node);done.add(node)
for cid in graph:dfs(cid,[])
check(not cycles,'prerequisite graph is acyclic and has no self-links')
for c in k['concepts']:
    check(c['id'] not in c['explanation_concept_ids'],'explanation has no self-link '+c['id'])
    norm=lambda s:unicodedata.normalize('NFKC',s).strip().casefold()
    if len({norm(a) for a in c['aliases']})!=len(c['aliases']):errors.append('duplicate aliases '+c['id'])
check(not any('duplicate aliases' in e for e in errors),'per-concept aliases unique after normalization')
alias_collisions=[a for a in k['alias_index'] if len(a['concept_ids'])>1]
check(all(a['requires_context']==(len(a['concept_ids'])>1) for a in k['alias_index']),'alias ambiguity explicitly labelled')
for a in alias_collisions:warnings.append('context required: '+a['alias']+' -> '+', '.join(a['concept_ids']))
for s in k['sources']:
    if s['kind'].startswith('local'):
        target=ROOT/s['path']; original=Path(s['original_path'])
        check(target.is_file(),'source copy exists '+s['id'])
        if target.is_file():check(sha256(target.read_bytes()).hexdigest()==s['sha256'],'source copy hash '+s['id'])
        check(original.is_file() and sha256(original.read_bytes()).hexdigest()==s['sha256'],'original file hash '+s['id'])
        if s['kind']=='local_pdf':
            pp=[p['pdf_page'] for p in pages if p['source_id']==s['id']]
            check(pp==list(range(1,s['page_count']+1)),'PDF page inventory '+s['id'])
for a in k['anchors']:
    if a['page_id']:
        p=pindex[a['page_id']]; t=p['normalized_text']
        check(0<=a['start']<a['end']<=len(t) and t[a['start']:a['end']]==a['quote'],'anchor quote '+a['id'])
        check(a['source_id']==p['source_id'] and a['pdf_page']==p['pdf_page'],'anchor page '+a['id'])
    else:
        check(index[a['source_id']]['kind']=='web' and bool(a['locator']),'web anchor locator '+a['id'])
spans=defaultdict(list)
for a in k['annotations']:
    t=pindex[a['page_id']]['normalized_text']; s,e=a['start'],a['end']
    if not(0<=s<e<=len(t) and t[s:e]==a['text']):errors.append('annotation span '+a['id'])
    if a['utf16_start']!=len(t[:s].encode('utf-16-le'))//2 or a['utf16_end']!=len(t[:e].encode('utf-16-le'))//2:errors.append('UTF16 span '+a['id'])
    spans[a['page_id']].append((s,e))
for pid,ss in spans.items():
    ss.sort()
    if any(a[1]>b[0] for a,b in zip(ss,ss[1:])):errors.append('overlap '+pid)
check(not any(any(w in e for w in ('annotation span','UTF16 span','overlap')) for e in errors),'annotation offsets, UTF16 coordinates and non-overlap')
for f in k['figures']:check((ROOT/f['preview_path']).is_file(),'figure page preview '+f['id'])
for p in k['parameters']:
    check((p['value'] is None)==(p['status']=='not_reported_in_read_sources'),'parameter known/unknown '+p['id'])
dois=[p['doi'].lower().strip() for p in k['papers']+k['candidate_readings'] if p['doi']]
check(len(dois)==len(set(dois)),'DOI deduplication across papers and candidates')
check(all(p['full_text_read_by_this_build'] is False for p in k['candidate_readings']),'candidate reading status preserved')
check(index['param.Lx']['value']==index['param.L1']['value']*len(index['param.lengths']['value']),'supercell length equals ten pitches')
theta=math.degrees(math.asin(850/1200)); critical=math.degrees(math.asin(1-850/1200))
check(abs(theta-45.0994720393)<1e-5,'normal-incidence target angle')
check(abs(critical-16.9577633000)<.01,'critical incident angle')
r=read('sources/course_results.json')
# Locate numbers without depending on presentation labels in historical JSON.
nums=[]
def numbers(x):
    if isinstance(x,dict):
        for v in x.values():numbers(v)
    elif isinstance(x,list):
        for v in x:numbers(v)
    elif isinstance(x,(int,float)):nums.append(x)
numbers(r)
eta=.7503848536757043; reflect=.7581377340359726; g=.9897737838229004
check(all(any(abs(n-x)<1e-10 for n in nums) for x in (eta,reflect,g)),'reported historical power values match copied JSON')
check(abs(eta-reflect*g)<1e-12,'absolute order efficiency equals R times grating fraction')
check(index['param.gold_course']['origin']=='course_replacement' and index['param.gold_model']['origin']=='author_material','author and course material models separated')
# Inspect all local review links and element anchors after rendering.
class H(HTMLParser):
    def __init__(self):super().__init__();self.ids=set();self.links=[]
    def handle_starttag(self,tag,attrs):
        d=dict(attrs)
        if 'id' in d:self.ids.add(d['id'])
        for key in ('href','src'):
            if key in d:self.links.append(d[key])
html_files=list(ROOT.glob('*.html'))+list((ROOT/'review').glob('*.html'))
parsed={}
for file in html_files:
    h=H();h.feed(file.read_text(encoding='utf-8'));parsed[file.resolve()]=h
for file,h in parsed.items():
    for link in h.links:
        u=urlsplit(link)
        if u.scheme or u.netloc:continue
        dest=(file.parent/unquote(u.path)).resolve() if u.path else file
        if dest==(ROOT/'evidence/validation_report.json').resolve():continue # This run creates the linked report below.
        if not dest.exists():errors.append('HTML missing link '+str(file.name)+' -> '+link)
        elif u.fragment and dest.suffix=='.html' and dest in parsed and unquote(u.fragment) not in parsed[dest].ids:errors.append('HTML missing anchor '+link)
check(len(html_files)>=4 and not any('HTML missing' in e for e in errors),'review HTML files and all local links')
mentioned={cid for a in k['annotations'] for cid in a['concept_ids']}
coverage={'matched_concepts':len(mentioned),'total_concepts':len(k['concepts']),
          'unmatched_concept_ids':sorted(set(graph)-mentioned),
          'meaning':'Dictionary occurrence coverage only. Pedagogical concepts need not occur verbatim in source PDFs; text matching is not manual semantic annotation.'}
report={'status':'PASS' if not errors else 'FAIL','validated_on':'2026-10-31','errors':errors,'warnings':warnings,
        'counts':{key:len(value) for key,value in k.items() if isinstance(value,list)},'check_count':len(checks),
        'checks':checks,'prerequisite_cycles':cycles,'alias_collisions':alias_collisions,'annotation_coverage':coverage,
        'derived_checks':{'theta_deg':theta,'critical_deg':critical,'eta_absolute':eta,'reflected_fraction':g},
        'validation_scope':'Structural, references, copied source hashes, anchor substrings, formula references and selected physical arithmetic. Scientific explanations and figure mapping were also reviewed; external candidate full texts remain pending.'}
(ROOT/'evidence/validation_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({key:report[key] for key in ['status','errors','warnings','counts','check_count','annotation_coverage']},ensure_ascii=False,indent=2))
raise SystemExit(1 if errors else 0)
